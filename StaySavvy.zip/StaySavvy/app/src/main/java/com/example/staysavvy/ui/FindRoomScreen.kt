package com.example.staysavvy.ui

import android.app.Activity
import android.app.DatePickerDialog
import android.widget.DatePicker
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.outlined.DateRange
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.firebase.auth.PhoneAuthOptions
import com.google.firebase.auth.PhoneAuthProvider
import java.util.Calendar
import java.util.Date
import java.util.concurrent.TimeUnit

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FindRoomScreen(staySavvyViewModel: StaySavvyViewModel){
    val place by staySavvyViewModel.place.collectAsState()
    val checkIn by staySavvyViewModel.checkIn.collectAsState()
    val checkOut by staySavvyViewModel.checkOut.collectAsState()


    Column (modifier = Modifier.background(color = Color(217,202,179))
        .fillMaxSize()
        .padding(
            top = 50.dp,
            start = 20.dp, end = 20.dp
        ),
        ){
        Text(text = "Find Room",
            fontSize = 24.sp,
            fontWeight = FontWeight.Bold,
            maxLines = 1,
            textAlign = TextAlign.Left,
            modifier = Modifier.padding(start = 10.dp)
            )
        TextField(
            value =place,
            onValueChange ={
                staySavvyViewModel.setPlace(it)
            } ,
            leadingIcon = {
                Icon(imageVector = Icons.Default.LocationOn, contentDescription = "place")
            },
            label = {
                Text(text = "Where you want to go?")
            },
            modifier = Modifier
                .fillMaxWidth()
                .padding(10.dp),
            colors = TextFieldDefaults.textFieldColors(
                containerColor = Color(160,147,125),
                focusedLabelColor = Color(246,230,203),
                focusedIndicatorColor = Color(246,230,203),
                focusedLeadingIconColor = Color(246,230,203),
                unfocusedLeadingIconColor = Color(246,230,203),
                unfocusedLabelColor = Color(246,230,203)
            )
        )
        MyDatePicker("Checkin Date", checkIn, { staySavvyViewModel.setCheckIn(it) })
        MyDatePicker("Checkout Date", checkOut, { staySavvyViewModel.setCheckOut(it) })
        TextField(
            value =place,
            onValueChange ={
                staySavvyViewModel.setPlace(it)
            } ,
            leadingIcon = {
                Icon(imageVector = Icons.Default.Home, contentDescription = "Number of Rooms")
            },
            label = {
                Text(text = "Number of Rooms")
            },
            modifier = Modifier
                .fillMaxWidth()
                .padding(10.dp),
            colors = TextFieldDefaults.textFieldColors(
                containerColor = Color(160,147,125),
                focusedLabelColor = Color(246,230,203),
                focusedIndicatorColor = Color(246,230,203),
                focusedLeadingIconColor = Color(246,230,203),
                unfocusedLeadingIconColor = Color(246,230,203),
                unfocusedLabelColor = Color(246,230,203)
            )
        )
        Card(modifier = Modifier
            .clickable {

            }
            .fillMaxWidth()
            .height(80.dp)
            .padding(10.dp),
            colors = CardDefaults.cardColors(
                containerColor = Color.Black
            )) {
            Column(modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = "Search",
                    fontSize = 20.sp,
                    textAlign = TextAlign.Center,
                    color =  Color(246,230,203),

                    )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MyDatePicker(
    label: String,
    check: String,
    dateValue: (String) -> Unit,
) {
    val mContext = LocalContext.current
    val mYear: Int
    val mMonth: Int
    val mDay: Int

    val mCalendar = Calendar.getInstance()

    mYear = mCalendar.get(Calendar.YEAR)
    mMonth = mCalendar.get(Calendar.MONTH)
    mDay = mCalendar.get(Calendar.DAY_OF_MONTH)

    mCalendar.time = Date()

    val mDatePickerDialog = DatePickerDialog(
        mContext,
        { _: DatePicker, mYear: Int, mMonth: Int, mDayOfMonth: Int ->
            dateValue("$mDayOfMonth/${mMonth + 1}/$mYear")
        }, mYear, mMonth, mDay
    )

    TextField(
        value = check,
        onValueChange = { dateValue(it)
        },
        label = { Text(label) },
        //enabled = false,
        modifier = Modifier
            .clickable { mDatePickerDialog.show() }
            .fillMaxWidth().padding(10.dp),
        leadingIcon = {
            Icon(imageVector = Icons.Default.DateRange, contentDescription = "Date")
        },
        colors = TextFieldDefaults.textFieldColors(
            containerColor = Color(160,147,125),
            focusedLabelColor = Color(246,230,203),
            focusedIndicatorColor = Color(246,230,203),
            focusedLeadingIconColor = Color(246,230,203),
            unfocusedLeadingIconColor = Color(246,230,203),
            unfocusedLabelColor = Color(246,230,203)
        )

    )
}
