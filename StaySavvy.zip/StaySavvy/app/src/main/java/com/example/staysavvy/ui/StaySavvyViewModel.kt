package com.example.staysavvy.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.google.firebase.auth.FirebaseUser
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch

class StaySavvyViewModel: ViewModel() {

    private val _user=MutableStateFlow<FirebaseUser?>(null)
    val user:MutableStateFlow<FirebaseUser?>get() = _user

    private val _name= MutableStateFlow("")
    val name:MutableStateFlow<String>get() = _name

    private val _phoneNumber= MutableStateFlow("")
    val phoneNumber:MutableStateFlow<String>get() = _phoneNumber

    private val _otp=MutableStateFlow("")
    val  otp:MutableStateFlow<String>get() = _otp

    private val _email= MutableStateFlow("")
    val email:MutableStateFlow<String>get() = _email

    private val _verificationId=MutableStateFlow("")
    val verificationId:MutableStateFlow<String>get() = _verificationId

    private val _ticks =MutableStateFlow(60L)
    val ticks :MutableStateFlow<Long>get() = _ticks

    private val _loading=MutableStateFlow(false)
    val loading :MutableStateFlow<Boolean>get() = _loading

    private val _place=MutableStateFlow("")
    val place:MutableStateFlow<String>get() = _place

    private val _checkIn=MutableStateFlow("")
    val checkIn:MutableStateFlow<String>get() = _checkIn

    private val _checkOut=MutableStateFlow("")
    val checkOut:MutableStateFlow<String>get() = _checkOut


    private lateinit var timerJob: Job

    fun setUser(user: FirebaseUser){
        _user.value=user
    }

    fun setName(name:String){
        _name.value=name
    }

    fun setPhoneNumber(phoneNumber:String){
        _phoneNumber.value=phoneNumber
    }

    fun setOtp(otp:String){
        _otp.value=otp
    }

    fun setEmail(email:String){
        _email.value=email
    }

    fun setVerificationId(verificationId:String){
        _verificationId.value=verificationId
    }

    fun setPlace(place:String){
        _place.value=place
    }

    fun setCheckIn(checkIn:String){
        _checkIn.value=checkIn
    }

    fun setCheckOut(checkOut:String){
        _checkOut.value=checkOut
    }

    fun runTimer(){
        timerJob=viewModelScope.launch {
            while (_ticks.value>0){
                delay(1000)
                _ticks.value-=1
            }
        }
    }

    fun setLoading(isLoading:Boolean){
        _loading.value=isLoading
    }

    fun resetTimer(){
        try {
            timerJob.cancel()
        }catch (exception:Exception){

        }finally {
            _ticks.value=60
        }
    }
}