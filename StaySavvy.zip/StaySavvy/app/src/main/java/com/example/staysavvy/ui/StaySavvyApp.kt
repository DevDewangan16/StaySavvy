package com.example.staysavvy.ui

import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import androidx.navigation.compose.rememberNavController
import com.google.firebase.auth.FirebaseAuth

val auth=FirebaseAuth.getInstance()
@Composable
fun StaySavvyApp(staySavvyViewModel: StaySavvyViewModel= viewModel(),
                 navController: NavHostController= rememberNavController()) {
    val user by staySavvyViewModel.user.collectAsState()
    if (user==null){
        SignUpUi(staySavvyViewModel = staySavvyViewModel)
    }
    else{
        FindRoomScreen(staySavvyViewModel = staySavvyViewModel)
    }
}